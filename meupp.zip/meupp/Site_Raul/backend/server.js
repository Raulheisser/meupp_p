const express = require('express');
const cors = require('cors');
const conexao = require('./db');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public'))); 

// Rota de cadastro de usuário
app.post('/api/cadastrar', (req, res) => {
  const { nome, email, senha } = req.body;
  if (!nome || !email || !senha) {
    return res.status(400).json({ erro: 'Preencha todos os campos.' });
  }

  const sql = 'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)';
  conexao.query(sql, [nome, email, senha], (err) => {
    if (err) return res.status(500).json({ erro: 'Erro ao cadastrar usuário.' });
    res.status(201).json({ mensagem: 'Usuário cadastrado com sucesso!' });
  });
});

// Rota de login
app.post('/api/login', (req, res) => {
  const { email, senha } = req.body;

  const sql = 'SELECT * FROM usuarios WHERE email = ? AND senha = ?';
  conexao.query(sql, [email, senha], (err, resultados) => {
    if (err) return res.status(500).json({ erro: 'Erro no banco de dados.' });

    if (resultados.length === 0) {
      return res.status(401).json({ erro: 'Email ou senha inválidos.' });
    }

    res.json({ mensagem: 'Login realizado com sucesso!', usuario: resultados[0] });
  });
});

// Rota para enviar mensagem
app.post('/api/mensagem', (req, res) => {
  const { usuario, texto } = req.body;
  if (!usuario || !texto) {
    return res.status(400).json({ erro: 'Preencha todos os campos.' });
  }

  const sql = 'INSERT INTO mensagens (usuario, texto) VALUES (?, ?)';
  conexao.query(sql, [usuario, texto], (err) => {
    if (err) return res.status(500).json({ erro: 'Erro ao enviar mensagem.' });
    res.status(201).json({ mensagem: 'Mensagem enviada com sucesso!' });
  });
});

// Rota para listar mensagens
app.get('/api/mensagens', (req, res) => {
  const sql = 'SELECT * FROM mensagens ORDER BY id DESC';
  conexao.query(sql, (err, resultados) => {
    if (err) return res.status(500).json({ erro: 'Erro ao buscar mensagens.' });
    res.json(resultados);
  });
});

// Inicia o servidor
app.listen(3000, () => console.log('Servidor rodando em http://localhost:3000'));

