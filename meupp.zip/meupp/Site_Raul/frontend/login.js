document.getElementById("loginForm").addEventListener("submit", async function(event) {
    event.preventDefault();
  
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
  
    const resposta = await fetch('http://localhost:3000/api/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ email, senha })
    });
  
    const texto = await resposta.text();
    const msg = document.getElementById("loginMessage");
    msg.textContent = texto;
    msg.style.color = resposta.ok ? "green" : "red";
    alert(resposta.text);
  
    if (resposta.ok) {
      setTimeout(() => {
        window.location.href = "principal.html";
      }, 1500);
    }
  });
  